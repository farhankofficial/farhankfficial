FARHAN KHAN PORTFOLIO
======================
Open index.html in a browser or upload the folder to any normal web host.

Included:
- Responsive single-page portfolio
- FK monogram logo built as CSS (no external logo dependency)
- Dark premium/neon visual system
- Services, skills, work, about and contact sections
- WhatsApp contact flow
- Animated reveal effects
- No betting/gambling promotion; games are described as interactive experiences

Before publishing:
1. Replace concept project cards with real projects/screenshots/links.
2. Add your real email/social profiles if desired.
3. Connect the contact form to your preferred backend if you want email submissions.
4. For production payment work, document only the gateways/integrations you actually support.


DESIGN UPDATE
-------------
The latest version uses an off-white background with emerald green + champagne-gold gradients, improved professional intro copy, softer cards, and a mobile-first visual hierarchy.
